# Cocoa Farmer Yield Estimator
bags = int(input("Enter number of cocoa bags gotten: "))

income = bags * 850

# Adding the  bonus
if bags > 100:
    income += 2000

#  final income
print("Total income is GHS", income)