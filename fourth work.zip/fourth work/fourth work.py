# Create the dictionary
savings = { 'Akosua': 800, 'Ama': 150, 'Adwoa': 390 }

print("Current savings:")
print(savings)

name = input("Enter name: ")
amount = int(input("Enter new amount: "))

if name in savings:
    savings[name] = amount
    print("Savings updated.")
else:
    print("Name not found.")


print("Updated savings:")
print(savings)