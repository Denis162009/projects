# Student Grade system

while True:
    score = int(input("Enter the student's score (0–100): "))

    if score < 0 or score > 100:
        print("Invalid score. Please enter a score between 0 and 100.")
    elif score >= 80:
        print("Grade is A")
    elif score >= 70:
        print("Grade is B")
    elif score >= 60:
        print("Grade is C")
    elif score >= 50:
        print("Grade is D")
    elif score >= 40:
        print("Grade is E")
    else:
        print("Grade is F")

    option = input("Would you like to check more grades (yes or no): ").lower()
    if option == 'yes':
        continue
    elif option == 'no':
        print("Thank you for using the Student Grade System.")
        break
    else:
        print("Invalid input. Exiting program.")
        break