
while True:
    route = input("Enter route (Madina, Kasoa, Tema): ")

    if route == "Madina":
        fare = 5
        print("The fare will be", fare, 'ghana cedis')
    elif route == "Kasoa":
        fare = 10
        print("The fare will be", fare, 'ghana cedis')
    elif route == "Tema":
        fare = 8
        print("The fare will be", fare, 'ghana cedis')
    else:
        print("Invalid route. Try again.")
        continue

    passengers = int(input("How many passengers? "))
    total = fare * passengers
    print('the total fare for',passengers, 'passengers would be ',total, 'ghana cedis')
    option = str(input("Would you like to change the route (yes or no): "))
    if option == 'yes':
        continue
    if option == 'no':
        break
    else:
        print("invalid input. Please try again.")
        break








